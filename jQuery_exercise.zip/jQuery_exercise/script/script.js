console.log('Script file loaded.');

$(document).ready(function(){

  console.log('HTML file loaded and parsed.');
  
/*------------  On click  --------------*/
  $('#clickedSection').click(function(){
    $('#clickedSection').css('border', '1px solid blue');
    setTimeout( function(){ 
      $('#clickedSection').css('border', 'none')
    }  , 2000 );
  });

  /*------------  Mouse enter + mouse leave --------------*/
  $('#mouseEnter').mouseenter(function(){
    $('#mouseEnter').css('backgroundColor', 'aqua');
  });
  $('#mouseEnter').mouseleave(function(){
    $('#mouseEnter').css('backgroundColor', 'aquamarine');
  });

/*------------  Show and Hide  --------------*/

  $("#slideUp").click(function(){
    $("#slideToHide").slideUp();
  });
  $("#slideUp").click(function(){
    $("#slideToHide").slideDown();
  });


/*------------  Show and Hide  --------------*/
  $('#show').click(function() {
    showP('#showHide');
  }
  );
  $('#hide').click(function() {
    hideP('#showHide');
  }
  );

    
});

/*------------  show and hide --------------*/
function showP(paragraphId){
  $(paragraphId).show();
}

function hideP(paragraphId){
  $(paragraphId).hide();
}















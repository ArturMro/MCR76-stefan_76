console.log('Script file loaded.');



(function(){
  'use strict';

  angular.module("myApp", [])
    .controller("myCtrl", function($scope) {
      $scope.result = function(){
      var one = $scope.numOne || 0;  
      var two = $scope.numTwo || 0;
        if ($scope.operator == 'division') {
          return one / two;
        }
        if ($scope.operator == 'addition') {
          return one + two;
        }
        if ($scope.operator == 'substraction') {
          return one - two;
        }
        if ($scope.operator == 'multiplication') {
          return one * two;
        }
      };
    });

})();

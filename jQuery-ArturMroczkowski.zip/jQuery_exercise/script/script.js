console.log('Script file loaded.');

$(document).ready(function(){

  console.log('HTML file loaded and parsed.');
  
//    *------------  On click  --------------*
  $('#clickedSection').click(function(){
    $('#clickedSection').css('border', '1px solid blue');
    setTimeout( function(){ 
      $('#clickedSection').css('border', 'none')
    }  , 2000 );
  });

  //    *------------  Mouse enter + mouse leave --------------*
  $('#mouseEnter').mouseenter(function(){
    $('#mouseEnter').css('backgroundColor', 'aqua');
  });
  $('#mouseEnter').mouseleave(function(){
    $('#mouseEnter').css('backgroundColor', 'rgb(184, 250, 229)');
  });

//   *------------  Show and Hide  --------------*

  $("#slideUp").click(function(){
    $("#slideToHide").slideUp();
  });
  $("#slideUp").click(function(){
    $("#slideToHide").slideDown();
  });


//    *------------  Show and Hide  --------------*
  $('#show').click(function() {
    showP('#showHide');
  }
  );
  $('#hide').click(function() {
    hideP('#showHide');
  }
  );

  //   * --------------  accordion  -----------------*

$(".accordion").click(function(){
  $(this).each(function(){
    $(this).next().slideToggle();

  });
  if( $('.span1').hasClass('seen')){
    $('.span1').removeClass('seen').addClass('hidden')
  }else{
    $('.span1').removeClass('hidden').addClass('seen')
  }
  if( $('.span2').hasClass('hidden')){
    $('.span2').removeClass('hidden').addClass('seen')
  }else{
    $('.span2').removeClass('seen').addClass('hidden')
  }
});

    
});

//   *------------  show and hide --------------*
function showP(paragraphId){
  $(paragraphId).show();
}

function hideP(paragraphId){
  $(paragraphId).hide();
}









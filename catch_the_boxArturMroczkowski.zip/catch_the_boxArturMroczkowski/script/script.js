console.log('Script file loaded.');

$(document).ready(function(){

  var clicked = 0;
  var missed = 0;
  var boxWidth = $('#wrapper').innerWidth() - 200;   // "minus" 200 to make sure box stays inside parent container
  var boxHeight = $('#wrapper').innerHeight() - 200;   // "minus" 200 to make sure box stays inside parent container

// function to move box
$('#theBox').mouseenter(function(){
  $('#theBox').css({"left": Math.random() * boxWidth, "top": Math.random() * boxHeight})   //changing position:relative randomly
  $('#missed').html(missed += 1);
 
 //after 20 missed clicks game over
  if(missed == 20){
    $('#overlay').css('display', 'block');
  }

  //button will refresh the page
  $('#reset').click(function() {
    location.reload();
});
});

//function for when player acctually click a box
$('#theBox').click(function(){
  $('#theBox').css({"left": Math.random() * boxWidth, "top": Math.random() * boxHeight})
  $('#clicked').html(clicked += 1);
});





});







//pseudo code... 

// one visible element
//when page load it display that element(square)
//when user move mouse over that element it disapear   ------> by change position
// box apear somewhere else on the screen

//..but than got new ideas..

//sometimes box apeared nearly in the same place so it could be clicked
//so i added similar function with "click" instead of "mouseover"
//and decided to add counter to see how many tries player had





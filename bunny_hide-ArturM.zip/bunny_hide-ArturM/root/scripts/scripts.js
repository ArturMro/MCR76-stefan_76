console.log('Script file loaded.');

$(document).ready(function(){

  console.log('HTML file loaded and parsed.');

  addMyEventListeners();
  
  
$('#leftEar').velocity({opacity: 1}, 2000 );
$('#rightEar').velocity({opacity: 1}, 2000 );
$('#rightArm').velocity({opacity: 1}, 2000 );
$('#leftArm').velocity({opacity: 1}, 2000 );
$('#rightLeg').velocity({opacity: 1}, 2000 );
$('#leftLeg').velocity({opacity: 1}, 2000 );
$('#belly').velocity({opacity: 1}, 2000 );
$('#head').velocity({opacity: 1}, 2000 );


/*$('#forHead').on('click', function(){
  showElement('#head');
});*/
$('#forHead').on('click', function(){
  showElement('#head');
});



$('#forBelly').on('click', function(){
  showElement('#belly');
});
$('#forLeftEar').on('click', function(){
  showElement('#leftEar');
});
$('#forRightEar').on('click', function(){
  showElement('#rightEar');
});
$('#forLeftArm').on('click', function(){
  showElement('#leftArm');
});
$('#forRightArm').on('click', function(){
  showElement('#rightArm');
});
$('#forLeftLeg').on('click', function(){
  showElement('#leftLeg');
});
$('#forRightLeg').on('click', function(){
  showElement('#rightLeg');
});


function showElement(id){
$(id).animate({'opacity': 'toggle'});
  };
  //$(id).velocity({opacity: 'toggle'}, 1000);  //velocity here doesnt work or i dont know how to use it
  //};



});


function addMyEventListeners(){


      
};










$('div:nth-child(1)').velocity({opacity:0}, 1000);

$('div:nth-child(2)').velocity({
  backgroundColor: '#2abbc0', backgroundColorAlpha: 1
}, 1000);
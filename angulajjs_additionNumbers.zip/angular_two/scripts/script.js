console.log('Script file loaded.');


(function(){
  'use strict';

  var myString = 'Hello Welt';

  angular.module("myApp", [])

    .controller("myCtrl", function($scope) {
      $scope.currentYear = 2020;
      $scope.displayCurrentMonth = function(){
        $scope.currentMonth = 'July';
      };

      $scope.addNumbers = function(){
      var three = $scope.numThree || 0;  // added || 0 to avoid NaN as result
      var four = $scope.numFour || 0;
        $scope.addition = three + four;
      };
    });

})();





































console.log('Script file loaded.');

$(document).ready(function(){

  console.log('HTML file loaded and parsed.');
  
  addMyEventListener()
 
  
});



function addMyEventListener(){

	

    // Contact Form script
    $('#submitButton').on('click', function(event){
        
        var name = $('#name').val();
        var company = $('#companyName').val();
        var phone = $('#phone').val();
        var budget = $('#budget').val();
        var email = $('#email').val();

        // in variable called email pattern is simple Regular Expression to validate email address
        //[a-z0-9._%+-]  -----this part is checking beginning of a RegExp - its looking for alphabet chars from 'a' to 'z', numbers from 0 to 9, and characters like ._%+-
        //+@  -----this part looks for '@' sign 
        //[a-z0-9.-]   ------this is looking for 'a' to 'z' chars numbers from 0 to 9
        //+\.     ----- this is adding a dot '.' to our RegExp
        //[a-z]{2,16}$   -----this is looking for 'a' to 'z' letters in strings made of min 2 and max 16 letters
        var emailPattern = /[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,16}$/;

        //if we keep clicking send button our if statements below will continue to add text if input fields are empty
        // so on every click send button we need to empty errorMessage - we can do it with .empty() method
        $('#errorMessage').empty();
        //We need to make sure that our form isnt submited before full filled and validated
        //We will use preventDefault() method to prevent submiting to early
        //event.preventDefault();
        
        if( name ==''){   //we check if name input isnt empty if it is user will see message that this input is empty and form will not be send
            $('#errorMessage').append('Please fill Name field. ');
            event.preventDefault();
        }
        else if( name !='' && name.length <3){   //when name input is not empty we check length of name, if its shorter than 3 letters user will see error message and form will not be send
            $('#errorMessage').append('Please fill proper name(min 3 letters). ');
            event.preventDefault();
        }
        else if( company ==''){   //we check if company input isnt empty if it is user will see message that this input is empty and form will not be send
            $('#errorMessage').append('Please fill Company field. ');
            event.preventDefault();
        }
        else if( phone ==''){   //we check if phone input isnt empty if it is user will see message that this input is empty and form will not be send
            $('#errorMessage').append('Please fill Phone field. ');
            event.preventDefault();
        }
        else if( phone !='' && phone.length < 10 || isNaN(phone)){  //when phone input is shorter than 10 and when user does not put numbers user will see error message and form will not be send
            $('#errorMessage').append('Please enter valid Phone number(min 10 digits). ');
            event.preventDefault();
        }
        else if( budget ==''){   //we check if budget input isnt empty if it is user will see message that this input is empty and form will not be send
            $('#errorMessage').append('Please fill Budget field. ');
            event.preventDefault();
        }
        else if( budget !='' && isNaN(budget) && budget !=''){   //when budget input is not empty we check if user put number, if it is not a number user will see error message and form will not be send
            $('#errorMessage').append('Please fill Budget field with a number. ');
            event.preventDefault();
        }
        else if( email ==''){   //we check if email input isnt empty if it is user will see message that this input is empty and form will not be send
            $('#errorMessage').append('Please fill email field. ');
            event.preventDefault();
        }
        else if( email !='' && !email.match(emailPattern)){   //we check if entered email address is in correct format( .match() method ), if not user will see message that this input is not correct and form will not be send
            $('#errorMessage').append('Please fill correct email address. Email should contain "@" and "." signs. ');
            event.preventDefault();
        }else{        

            $.post('https://mycourseresource.com/mcr76/po3-artur.php',  //Send request to server
                    {'key': 'PO3',                                      
                    'name':$('#name').val(), 
                    'company name':$('#companyName').val(), 
                    'phone number':$('#phone').val(), 
                    'budget':$('#budget').val(), 
                    'email':$('#email').val(),
                    'notify':true,                                      //this can be changed to false
                    'format':'json'},
                    function(data, status){                             //Request sent data and status
                        var jsObject = JSON.parse(data);                //Json to text
                    }
                );
                    
                alert('Thank you for filling out contact form. We will get to you soon!');
                $('form')[0].reset();       //Reset form, empty input fields
                return false;               //Prevent reloading page
        }
    });      
}


